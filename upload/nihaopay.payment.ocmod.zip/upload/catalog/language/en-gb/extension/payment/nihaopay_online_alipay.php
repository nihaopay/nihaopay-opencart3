<?php
// Text
$_['text_title']           = '<img src="catalog/view/theme/default/image/alipay.png" height="20" alt="AliPay" /> AliPay';
