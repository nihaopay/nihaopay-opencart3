<?php
// Text
$_['text_title']           = '<img src="catalog/view/theme/default/image/wx.png" height="20" alt="WechatPay" /> WechatPay';
