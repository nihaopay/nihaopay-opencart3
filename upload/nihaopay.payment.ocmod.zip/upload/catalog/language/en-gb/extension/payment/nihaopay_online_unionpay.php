<?php
// Text
$_['text_title']           = '<img src="catalog/view/theme/default/image/up.png" height="20" alt="UnionPay" /> UnionPay';
